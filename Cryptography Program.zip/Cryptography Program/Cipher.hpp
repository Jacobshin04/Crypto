class Cipher
{
	public:
	void Start();	
};
