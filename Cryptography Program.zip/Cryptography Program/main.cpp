#include <iostream>
#include <string>
#include <cstdlib>
#include <limits>
#include "Cipher.hpp"


using namespace std;


int main()
{
	Cipher c1;
	c1.Start();
} //end of "main"

